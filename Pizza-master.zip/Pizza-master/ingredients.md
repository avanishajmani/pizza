the Ingredients used to make pizza:

Yeast
sugar
Flour
olive oil
salt
vegetables
cheese
corn meal
pizza sauce
