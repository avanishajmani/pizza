# My recipe
It is a recipe of pizza 


the Ingredients used to make pizza:

Yeast
sugar
Flour
olive oil
salt
vegetables
cheese
corn meal
pizza sauce



recipe to make a pizza :

Step 1: Pour luke warm water to a warm bowl

Step 2: Add yeast to the warm water.

Step 3: Sprinkle sugar as well.

Step 4: Stir it gently. Allow this to rest undisturbed for 10 to 12 mins. The mixture must turn frothy and bubbly.

Step 5: When the yeast turns frothy, add flour.

Step 6:  Next add olive oil and salt.

Step 7: Mix to make dough. If needed add more water and knead the dough for 5 to 6 mins. The dough must turn very soft and elastic. When you poke your finger gently the dough must bounce back.

Step 8:  Make a ball and next apply a thin layer of oil to prevent the dough from drying up.

Step 9:  Cover with a moist cloth. Rest in a warm place until the dough doubles in size

Step 10: Next transfer the dough to the work area and punch it down to deflate.

Step 11: Sprinkle some corn meal evenly on a tray. Flatten a ball and add few drops of oil. Begin to spread and stretch the dough. Flatten to a 9 inch thin even base.

 Step 12: Next spread pizza sauce as desired.

Step 13:  Lastly layer cheese. Then veggies of your choice. 

Step 14:  Bake it for 8 to 10 minutes or until the cheese turns golden.

Step 15: Slice and serve






